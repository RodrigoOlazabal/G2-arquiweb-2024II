package backend.project.Model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@Table(name = "historial_consulta")
public class HistorialConsulta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long idConsulta;
    private LocalDate fechaRegistro;
    private String notasAdicionales;


    public HistorialConsulta(Long idConsulta, LocalDate fechaRegistro, String notasAdicionales) {
        this.idConsulta = idConsulta;
        this.fechaRegistro = fechaRegistro;
        this.notasAdicionales = notasAdicionales;

    }
}
