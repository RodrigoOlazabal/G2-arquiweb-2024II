package backend.project.Service;

import backend.project.Model.Usuario;
import org.springframework.stereotype.Service;

@Service
public interface UsuarioService
{
    Usuario insertUsuario(Usuario usuario);
    Usuario insertUsuario(String nombre,String correoElectronico, String contrasenia, String tipoUsuario);
    void deleteUsuario(Long usuarioId);

}