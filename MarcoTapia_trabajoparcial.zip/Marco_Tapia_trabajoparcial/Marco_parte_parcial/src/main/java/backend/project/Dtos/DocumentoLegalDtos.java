package backend.project.Dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DocumentoLegalDtos {
    private Long idDocumento;
    private String tituloDocumento;
    private String descripcionDocumento;
    private String urlDocumento;
    private LocalDate fechaPublicacion;
    private String tipoDocumento;
    private Boolean accesoFreemium;
    private Long idUsuario;

}
