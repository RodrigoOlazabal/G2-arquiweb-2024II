package backend.project.Service;

import backend.project.Model.HistorialConsulta;

import java.time.LocalDate;
import java.util.List;

public interface HistorialConsultaService {
    HistorialConsulta insertHistorialConsulta(HistorialConsulta historialConsulta);
    HistorialConsulta insertHistorialConsulta(Long idConsulta, LocalDate fechaRegistro, String notasAdicionales);
    void deleteHistorialConsulta(Long idHistorialConsulta);
    HistorialConsulta findById(Long id);
    List<HistorialConsulta> ListAllHistorialConsulta();
}
