package backend.project.Repository;

import backend.project.Model.HistorialConsulta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HistorialConsultaRepository extends JpaRepository<HistorialConsulta, Long> {
}
