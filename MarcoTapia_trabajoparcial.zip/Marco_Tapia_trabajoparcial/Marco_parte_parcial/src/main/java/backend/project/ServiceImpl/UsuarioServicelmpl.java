package backend.project.ServiceImpl;

import backend.project.Model.Usuario;
import backend.project.Repository.UsuarioRepository;
import backend.project.Service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UsuarioServicelmpl implements UsuarioService {
    @Autowired
    private UsuarioRepository usuarioRepository;

    @Override
    public Usuario insertUsuario(Usuario usuario) {return usuarioRepository.save(usuario);}

    @Override
    public Usuario insertUsuario(String nombre, String correoElectronico, String contrasenia, String tipoUsuario) {
        Usuario usuario = new Usuario();
        usuario.setNombre(nombre);
        usuario.setCorreoElectronico(correoElectronico);
        usuario.setContrasenia(contrasenia);
        usuario.setTipoUsuario(tipoUsuario);

        return insertUsuario(usuario);
    }

    @Override
    public void deleteUsuario(Long usuarioId) { usuarioRepository.deleteById(usuarioId);}

}

