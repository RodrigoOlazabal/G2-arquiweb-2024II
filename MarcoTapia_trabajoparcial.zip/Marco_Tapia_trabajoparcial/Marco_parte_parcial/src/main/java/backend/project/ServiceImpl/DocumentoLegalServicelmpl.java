package backend.project.ServiceImpl;

import backend.project.Model.DocumentoLegal;
import backend.project.Repository.DocumentoLegalRepository;
import backend.project.Service.DocumentoLegalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class DocumentoLegalServicelmpl implements DocumentoLegalService {
    @Autowired
    private DocumentoLegalRepository documentoLegalRepository;
    @Override
    public DocumentoLegal insertDocumentoLegal(DocumentoLegal documentolegal) {return documentoLegalRepository.save(documentolegal);}
    @Override
    public DocumentoLegal insertDocumentoLegal(String tituloDocumento, String desripcionDocument, String URLdocumento, LocalDate fechaPublicacion, String tipoDocumento, Boolean accesoFremiun, Long usuarioId)
    {
        DocumentoLegal documentolegal = new DocumentoLegal();
        documentolegal.setTituloDocumento(tituloDocumento);
        documentolegal.setDescripcionDocumento(desripcionDocument);
        documentolegal.setUrlDocumento(URLdocumento);
        documentolegal.setFechaPublicacion(fechaPublicacion);
        documentolegal.setTipoDocumento(tipoDocumento);
        return insertDocumentoLegal(documentolegal);
    }

    @Override
    public void deleteDocumentoLegal(Long id) { documentoLegalRepository.deleteById(id);}

    @Override
    public DocumentoLegal findById(Long id) { return documentoLegalRepository.findById(id).orElse(null);
    }
    @Override
    public List<DocumentoLegal> listAllLDocumentoLegal() { return documentoLegalRepository.findAll();
    }
}
