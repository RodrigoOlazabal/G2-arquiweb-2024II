package backend.project.Controller;

import backend.project.Model.DocumentoLegal;
import backend.project.Service.DocumentoLegalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/documentolegal")
@CrossOrigin("*")
public class DocumentoLegalController {
    @Autowired
    private DocumentoLegalService documentoLegalService;
    @GetMapping("/list")
    public ResponseEntity<List<DocumentoLegal>> listarTodaslosDocumentolegales()
    {
        List<DocumentoLegal>documentoLegals = documentoLegalService.listAllLDocumentoLegal();
        if(documentoLegals.isEmpty()){
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(documentoLegals, HttpStatus.OK);
    }
    @PostMapping
    public ResponseEntity<DocumentoLegal> registrarDocumentoLegal(@RequestBody DocumentoLegal documentoLegal){
        DocumentoLegal nuevoDocumentoLegal = documentoLegalService.insertDocumentoLegal(documentoLegal);
        return new ResponseEntity<>(nuevoDocumentoLegal, HttpStatus.CREATED);
    }

        @DeleteMapping("/{id}")
        public ResponseEntity<Void> deleteDocumentoLegal(@PathVariable Long id) {
            documentoLegalService.deleteDocumentoLegal(id);
            return ResponseEntity.noContent().build();
        }
    }


