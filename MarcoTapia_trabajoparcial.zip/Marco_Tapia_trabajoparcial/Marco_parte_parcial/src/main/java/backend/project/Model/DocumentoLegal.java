package backend.project.Model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@Table(name = "documento_legal")
public class DocumentoLegal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String tituloDocumento;
    private String descripcionDocumento;
    private String urlDocumento;
    private LocalDate fechaPublicacion;
    private String tipoDocumento;
    private Boolean accesoFreemium;


    @ManyToOne
    @JoinColumn(name= "usuario_id")
    private Usuario usuario;

    public DocumentoLegal(String tituloDocumento, String descripcionDocumento, String urlDocumento, LocalDate fechaPublicacion, String tipoDocumento, Boolean accesoFreemium, Usuario usuario) {
        this.tituloDocumento = tituloDocumento;
        this.descripcionDocumento = descripcionDocumento;
        this.urlDocumento = urlDocumento;
        this.fechaPublicacion = fechaPublicacion;
        this.tipoDocumento = tipoDocumento;
        this.accesoFreemium = accesoFreemium;
        this.usuario = usuario;
    }
}
