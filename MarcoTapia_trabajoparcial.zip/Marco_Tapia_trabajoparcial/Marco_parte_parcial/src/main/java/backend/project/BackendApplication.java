package backend.project;

import backend.project.Model.DocumentoLegal;
import backend.project.Model.HistorialConsulta;
import backend.project.Model.Usuario;
import backend.project.Repository.DocumentoLegalRepository;
import backend.project.Repository.HistorialConsultaRepository;
import backend.project.Repository.UsuarioRepository;
import backend.project.Service.DocumentoLegalService;
import backend.project.Service.HistorialConsultaService;
import backend.project.Service.UsuarioService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.context.annotation.Bean;

import java.time.LocalDate;


@SpringBootApplication(exclude = {SecurityAutoConfiguration.class})
public class BackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendApplication.class, args);
	}

	@Bean
	public CommandLineRunner mappingDemo(
			DocumentoLegalRepository documentoLegalRepository,
			DocumentoLegalService documentoLegalService,
			HistorialConsultaService historialConsultaService,
			HistorialConsultaRepository historialConsultaRepository,
			UsuarioRepository usuarioRepository,
			UsuarioService usuarioService
	)
	{
		return args -> {
			// Crear un usuario
			Usuario usuario1 = new Usuario("Juan Perez","juan.perez@example.com","password123","ADMIN");
			Usuario usuario2 = new Usuario("Maria Rodriguez","maria.rodrigez@example.com","password124","User");
			usuario1 = usuarioService.insertUsuario(usuario1);
			usuario2 = usuarioService.insertUsuario(usuario2);

			//Crear algunas DocumentosLegales
			//String tituloDocumento, String descripcionDocumento, String urlDocumento, LocalDate fechaPublicacion, String tipoDocumento, Boolean accesoFreemium, Usuario usuario
			DocumentoLegal documentoLegal1 = new DocumentoLegal("Casona", "Propiedad privada", "dawddaw", LocalDate.of(2021, 9, 10), "pdf", true, usuario1);
			DocumentoLegal documentoLegal2 = new DocumentoLegal("La casa matucita", "Propiedad ilicita", "gasda", LocalDate.of(2022, 10, 12), "word", false, usuario2);
			documentoLegalService.insertDocumentoLegal(documentoLegal1);
			documentoLegalService.insertDocumentoLegal(documentoLegal2);

			// HistorialLegal
			// Long idConsulta, LocalDate fechaRegistro, String notasAdicionales, DocumentoLegal
			HistorialConsulta historialConsulta1 = new HistorialConsulta(2L, LocalDate.of(2022, 12, 24), "Privada");
			HistorialConsulta historialConsulta2 = new HistorialConsulta(3L, LocalDate.of(2023,7,5),"Vendida");
			historialConsultaService.insertHistorialConsulta(historialConsulta1);
			historialConsultaService.insertHistorialConsulta(historialConsulta2);



// Mostrar feedbacks y mensajes
			System.out.println("DocumentoLegal:");
			for (DocumentoLegal documentoLegal : documentoLegalService.listAllLDocumentoLegal()) {
				System.out.println(documentoLegal);
			}

			System.out.println("HistorialConsulta:");
			for (HistorialConsulta historialConsulta : historialConsultaService.ListAllHistorialConsulta()) {
				System.out.println(historialConsulta);
			}

		};
	}

}
