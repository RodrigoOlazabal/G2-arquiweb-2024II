package backend.project.Controller;

import backend.project.Model.HistorialConsulta;
import backend.project.Service.HistorialConsultaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.ListPagingAndSortingRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/HistorialConsulta")
@CrossOrigin("*")
public class HistorialConsultaController {

    @Autowired
    private HistorialConsultaService historialConsultaService;
    @GetMapping("/list")
    public ResponseEntity<List<HistorialConsulta>>ListarTodosLosHistorialConsulta(){
        List<HistorialConsulta> historialConsulta = historialConsultaService.ListAllHistorialConsulta();
        if(historialConsulta.isEmpty()){
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);

        }
        return new ResponseEntity<>(historialConsulta, HttpStatus.OK);
    }
    @PostMapping
    public ResponseEntity<HistorialConsulta> InsertarHistorialConsulta(@RequestBody HistorialConsulta historialConsulta){
        HistorialConsulta nuevoHistorialConsulta = historialConsultaService.insertHistorialConsulta(historialConsulta);
        return new ResponseEntity<>(nuevoHistorialConsulta, HttpStatus.CREATED);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarHistorialConsulta(@PathVariable("id") Long id){
        historialConsultaService.deleteHistorialConsulta(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
