package backend.project.Service;

import backend.project.Model.DocumentoLegal;

import java.time.LocalDate;
import java.util.List;

public interface DocumentoLegalService {
    DocumentoLegal insertDocumentoLegal(DocumentoLegal documentolegal);
    DocumentoLegal insertDocumentoLegal(String tituloDocumento, String desripcionDocument, String URLdocumento, LocalDate fechaPublicacion, String tipoDocumento, Boolean accesoFremiun, Long usuarioId);
    void deleteDocumentoLegal(Long id);
    DocumentoLegal findById(Long id);
    List<DocumentoLegal> listAllLDocumentoLegal();
}
