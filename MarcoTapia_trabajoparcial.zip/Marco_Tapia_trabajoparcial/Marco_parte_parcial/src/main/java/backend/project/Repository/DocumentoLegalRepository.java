package backend.project.Repository;

import backend.project.Model.DocumentoLegal;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DocumentoLegalRepository extends JpaRepository<DocumentoLegal, Long> {
}
