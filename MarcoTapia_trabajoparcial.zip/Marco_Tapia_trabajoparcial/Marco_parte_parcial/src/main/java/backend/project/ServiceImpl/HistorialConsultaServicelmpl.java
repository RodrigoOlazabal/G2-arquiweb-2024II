package backend.project.ServiceImpl;


import backend.project.Model.HistorialConsulta;
import backend.project.Repository.HistorialConsultaRepository;
import backend.project.Service.HistorialConsultaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class HistorialConsultaServicelmpl implements HistorialConsultaService {
    @Autowired
    private HistorialConsultaRepository historialConsultaRespository;

    @Override
    public HistorialConsulta insertHistorialConsulta(HistorialConsulta historialConsulta) {
        return historialConsultaRespository.save(historialConsulta);
    }

    @Override
    public HistorialConsulta insertHistorialConsulta(Long idConsulta, LocalDate fechaRegistro, String notasAdicionales) {
        HistorialConsulta historialConsulta = new HistorialConsulta();
        historialConsulta.setIdConsulta(idConsulta);
        historialConsulta.setFechaRegistro(fechaRegistro);
        historialConsulta.setNotasAdicionales(notasAdicionales);

        return insertHistorialConsulta(historialConsulta);
    }

    @Override
    public void deleteHistorialConsulta(Long idHistorialConsulta) { historialConsultaRespository.deleteById(idHistorialConsulta); }

    @Override
    public HistorialConsulta findById(Long id) {return historialConsultaRespository.findById(id).orElse(null); }

    @Override
    public List<HistorialConsulta> ListAllHistorialConsulta() {return historialConsultaRespository.findAll();}

}
