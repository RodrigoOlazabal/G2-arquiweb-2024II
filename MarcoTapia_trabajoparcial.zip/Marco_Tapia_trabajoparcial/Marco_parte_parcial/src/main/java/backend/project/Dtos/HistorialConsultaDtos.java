package backend.project.Dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class HistorialConsultaDtos {
    private Long idHistorial;
    private Integer idConsulta;
    private LocalDate fechaRegistro;
    private String notasAdicionales;
    private Long idUsuario;
}
